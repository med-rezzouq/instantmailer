<template>
  <div>
    <div class="mb-6"><div class="page-title">Compose Campaign</div><div class="page-subtitle">Create and send your email campaign</div></div>
    <div class="grid grid-cols-[1fr_300px] gap-6">
      <div>
        <div class="card mb-4">
          <div class="mb-4"><label class="form-label">Campaign Name</label><input v-model="form.name" class="form-input" placeholder="e.g. May Newsletter"></div>
          <div class="grid grid-cols-2 gap-4 mb-4">
            <div><label class="form-label">Subject Line</label><input v-model="form.subject" class="form-input" placeholder="Your email subject..."></div>
            <div><label class="form-label">Preview Text</label><input v-model="form.preview_text" class="form-input" placeholder="Short preview..."></div>
          </div>
          <div>
            <label class="form-label">Email Body</label>
            <div class="flex gap-1 p-2 bg-surface-off dark:bg-surface-dark-off border border-border dark:border-border-dark border-b-0 rounded-t-lg flex-wrap">
              <button v-for="t in toolbarBtns" :key="t.cmd" @click="fmt(t.cmd)" class="w-7 h-7 flex items-center justify-center rounded text-gray-500 dark:text-gray-400 hover:bg-border dark:hover:bg-border-dark hover:text-gray-900 dark:hover:text-gray-100 text-sm font-bold transition-all" :title="t.label" v-html="t.icon"></button>
            </div>
            <div ref="editor" contenteditable="true" class="border border-border dark:border-border-dark rounded-b-lg p-4 min-h-[200px] bg-surface-off dark:bg-surface-dark-off focus:outline-none focus:border-primary dark:focus:border-primary-dark" style="color:inherit"></div>
          </div>
        </div>
        <div class="flex gap-3">
          <button class="btn btn-ghost" @click="saveDraft" :disabled="saving">Save Draft</button>
          <button class="btn btn-primary" @click="sendNow" :disabled="sending">
            <svg v-if="sending" class="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
            <svg v-else class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 2L11 13"/><path d="M22 2L15 22l-4-9-9-4 20-7z"/></svg>
            {{ sending ? 'Sending...' : 'Send Campaign' }}
          </button>
        </div>
      </div>
      <div>
        <div class="card mb-4">
          <div class="font-bold mb-4 text-sm">Sending Settings</div>
          <div class="mb-4"><label class="form-label">Email Provider</label>
            <select v-model="form.provider" class="form-input"><option value="microsoft">Microsoft 365</option><option value="google">Google Workspace</option></select>
          </div>
        </div>
        <div class="card">
          <div class="font-bold mb-3 text-sm">Quick Templates</div>
          <div v-if="!templates.length" class="text-sm text-gray-400 dark:text-gray-600">No templates yet</div>
          <button v-for="t in templates" :key="t.id" class="btn btn-ghost btn-sm w-full justify-start mb-2 text-left" @click="loadTemplate(t)">
            <svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/></svg>
            {{ t.name }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import api from '@/api'
import { useToastStore } from '@/stores/toast'

const toast = useToastStore(); const router = useRouter(); const route = useRoute()
const editor = ref(null); const saving = ref(false); const sending = ref(false)
const templates = ref([])
const form = ref({ name: '', subject: '', preview_text: '', provider: 'microsoft' })
const toolbarBtns = [
  { cmd: 'bold', label: 'Bold', icon: '<b>B</b>' },{ cmd: 'italic', label: 'Italic', icon: '<i>I</i>' },
  { cmd: 'underline', label: 'Underline', icon: '<u>U</u>' },
]

onMounted(async () => {
  try { templates.value = (await api.get('/templates?limit=20')).data } catch(_) {}
  if (route.query.template) editor.value.innerHTML = route.query.template
})

function fmt(cmd) { document.execCommand(cmd, false, null); editor.value.focus() }
function loadTemplate(t) { editor.value.innerHTML = t.html_content; toast.show('Template loaded', 'success') }

async function saveDraft() {
  saving.value = true
  try {
    await api.post('/campaigns', { ...form.value, html_content: editor.value.innerHTML || '<p></p>', segment_tags: [] })
    toast.show('Draft saved!', 'success')
  } catch(e) { toast.show(e.response?.data?.detail || e.message, 'error') } finally { saving.value = false }
}

async function sendNow() {
  if (!form.value.name) { toast.show('Campaign name is required', 'error'); return }
  if (!form.value.subject) { toast.show('Subject line is required', 'error'); return }
  if (!confirm('Send this campaign now?')) return
  sending.value = true
  try {
    const campaign = (await api.post('/campaigns', { ...form.value, html_content: editor.value.innerHTML || '<p></p>', segment_tags: [] })).data
    await api.post(`/campaigns/${campaign.id}/send`)
    toast.show('🚀 Campaign is sending!', 'success')
    form.value = { name: '', subject: '', preview_text: '', provider: 'microsoft' }
    editor.value.innerHTML = ''
    router.push('/campaigns')
  } catch(e) { toast.show(e.response?.data?.detail || e.message, 'error') } finally { sending.value = false }
}
</script>
