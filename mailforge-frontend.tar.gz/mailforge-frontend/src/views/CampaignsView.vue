<template>
  <div>
    <div class="flex items-center justify-between mb-6">
      <div><div class="page-title">Campaigns</div><div class="page-subtitle">All your email campaigns</div></div>
      <RouterLink to="/compose" class="btn btn-primary"><svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>New Campaign</RouterLink>
    </div>
    <CampaignsTable :campaigns="campaigns" @send="sendCampaign" @stats="viewStats" @delete="deleteCampaign" />
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import api from '@/api'
import { useToastStore } from '@/stores/toast'
import CampaignsTable from '@/components/CampaignsTable.vue'

const toast = useToastStore()
const campaigns = ref([])

onMounted(load)
async function load() {
  try { campaigns.value = (await api.get('/campaigns?limit=100')).data }
  catch(e) { toast.show('Failed to load campaigns', 'error') }
}
async function sendCampaign(id) {
  if (!confirm('Send this campaign?')) return
  try { await api.post(`/campaigns/${id}/send`); toast.show('Campaign sending!', 'success'); load() }
  catch(e) { toast.show(e.response?.data?.detail || e.message, 'error') }
}
async function deleteCampaign(id) {
  if (!confirm('Delete this campaign?')) return
  try { await api.delete(`/campaigns/${id}`); toast.show('Deleted', 'success'); load() }
  catch(e) { toast.show(e.message, 'error') }
}
function viewStats(c) { alert(`Stats for "${c.name}" — coming soon`) }
</script>
