<template>
  <header class="h-14 bg-surface dark:bg-surface-dark border-b border-border dark:border-border-dark flex items-center justify-between px-6 sticky top-0 z-40">
    <span class="text-sm text-gray-500 dark:text-gray-400 capitalize">{{ currentRoute }}</span>
    <div class="flex items-center gap-3">
      <span class="text-xs text-gray-400 dark:text-gray-600 bg-surface-off dark:bg-surface-dark-off border border-border dark:border-border-dark rounded-full px-3 py-0.5 font-mono">api: localhost:8000</span>
      <button @click="toggleTheme" class="w-9 h-9 flex items-center justify-center rounded-lg text-gray-500 dark:text-gray-400 hover:bg-surface-off dark:hover:bg-surface-dark-off transition-all">
        <svg v-if="isDark" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>
        <svg v-else width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
      </button>
      <div class="flex items-center gap-2">
        <div class="w-8 h-8 rounded-full bg-primary dark:bg-primary-dark flex items-center justify-center text-white text-xs font-bold">{{ initials }}</div>
        <span class="text-sm font-semibold">{{ auth.user?.name }}</span>
      </div>
      <button class="btn btn-ghost btn-sm" @click="logout">Logout</button>
    </div>
  </header>
</template>

<script setup>
import { computed, inject } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const auth    = useAuthStore()
const route   = useRoute()
const router  = useRouter()
const isDark  = inject('isDark')
const toggleTheme = inject('toggleTheme')

const currentRoute = computed(() => route.name || 'Dashboard')
const initials = computed(() => auth.user?.name?.charAt(0)?.toUpperCase() || 'U')

function logout() {
  auth.logout()
  router.push('/login')
}
</script>
